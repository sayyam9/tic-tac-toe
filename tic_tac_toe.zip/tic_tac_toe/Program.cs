﻿using System;

namespace UniqueTicTacToe
{
    public class UniqueGame
    {
        private char[,] gameBoard;
        private int currentPlayer;

        public UniqueGame()
        {
            gameBoard = new char[6, 6];
            currentPlayer = 1;
            InitializeBoard();
        }

        private void InitializeBoard()
        {
            for (int i = 0; i < 6; i++)
            {
                for (int j = 0; j < 6; j++)
                {
                    gameBoard[i, j] = ' ';
                }
            }
        }

        public void StartGame()
        {
            bool isRunning = true;

            while (isRunning)
            {
                Console.Clear();
                DrawBoard();
                MakeMove();
                isRunning = !CheckWin() && !CheckDraw();

                if (!isRunning)
                {
                    Console.Clear();
                    DrawBoard();
                    if (CheckWin())
                    {
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine($"Player {currentPlayer} wins!");
                    }
                    else if (CheckDraw())
                    {
                        Console.ForegroundColor = ConsoleColor.Yellow;
                        Console.WriteLine("It's a draw!");
                    }
                    Console.ResetColor();
                }
                else
                {
                    SwitchPlayer();
                }
            }
        }

        private void DrawBoard()
        {
            Console.WriteLine("  0   1   2   3   4   5");
            for (int i = 0; i < 6; i++)
            {
                Console.Write(i + " ");
                for (int j = 0; j < 6; j++)
                {
                    Console.ForegroundColor = ConsoleColor.White;
                    if (gameBoard[i, j] == '1')
                    {
                        Console.ForegroundColor = ConsoleColor.Blue;
                    }
                    else if (gameBoard[i, j] == '2')
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                    }

                    Console.Write(gameBoard[i, j]);
                    if (j < 5) Console.Write(" | ");
                }
                Console.WriteLine();
                if (i < 5) Console.WriteLine(" ---+---+---+---+---");
            }
            Console.ResetColor();
        }

        private void MakeMove()
        {
            int row, col;
            bool isValidMove;

            do
            {
                Console.WriteLine($"Player {currentPlayer}, enter your move (row and column): ");
                string input = Console.ReadLine();
                var parts = input.Split();
                if (parts.Length == 2 && int.TryParse(parts[0], out row) && int.TryParse(parts[1], out col))
                {
                    isValidMove = row >= 0 && row < 6 && col >= 0 && col < 6 && gameBoard[row, col] == ' ';
                    if (isValidMove)
                    {
                        gameBoard[row, col] = currentPlayer.ToString()[0];
                    }
                    else
                    {
                        Console.WriteLine("This move is not valid. Try again.");
                    }
                }
                else
                {
                    isValidMove = false;
                    Console.WriteLine("Invalid input. Please enter two numbers separated by space.");
                }
            } while (!isValidMove);
        }

        private void SwitchPlayer()
        {
            currentPlayer = currentPlayer == 1 ? 2 : 1;
        }

        private bool CheckWin()
        {
            // Check rows
            for (int i = 0; i < 6; i++)
            {
                if (gameBoard[i, 0] == currentPlayer.ToString()[0] && gameBoard[i, 1] == currentPlayer.ToString()[0] &&
                    gameBoard[i, 2] == currentPlayer.ToString()[0] && gameBoard[i, 3] == currentPlayer.ToString()[0] &&
                    gameBoard[i, 4] == currentPlayer.ToString()[0] && gameBoard[i, 5] == currentPlayer.ToString()[0])
                {
                    return true;
                }
            }

            // Check columns
            for (int i = 0; i < 6; i++)
            {
                if (gameBoard[0, i] == currentPlayer.ToString()[0] && gameBoard[1, i] == currentPlayer.ToString()[0] &&
                    gameBoard[2, i] == currentPlayer.ToString()[0] && gameBoard[3, i] == currentPlayer.ToString()[0] &&
                    gameBoard[4, i] == currentPlayer.ToString()[0] && gameBoard[5, i] == currentPlayer.ToString()[0])
                {
                    return true;
                }
            }

            // Check diagonals
            if (gameBoard[0, 0] == currentPlayer.ToString()[0] && gameBoard[1, 1] == currentPlayer.ToString()[0] &&
                gameBoard[2, 2] == currentPlayer.ToString()[0] && gameBoard[3, 3] == currentPlayer.ToString()[0] &&
                gameBoard[4, 4] == currentPlayer.ToString()[0] && gameBoard[5, 5] == currentPlayer.ToString()[0])
            {
                return true;
            }

            if (gameBoard[0, 5] == currentPlayer.ToString()[0] && gameBoard[1, 4] == currentPlayer.ToString()[0] &&
                gameBoard[2, 3] == currentPlayer.ToString()[0] && gameBoard[3, 2] == currentPlayer.ToString()[0] &&
                gameBoard[4, 1] == currentPlayer.ToString()[0] && gameBoard[5, 0] == currentPlayer.ToString()[0])
            {
                return true;
            }

            return false;
        }

        private bool CheckDraw()
        {
            foreach (var cell in gameBoard)
            {
                if (cell == ' ')
                {
                    return false;
                }
            }
            return true;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            UniqueGame game = new UniqueGame();
            game.StartGame();
        }
    }
}
